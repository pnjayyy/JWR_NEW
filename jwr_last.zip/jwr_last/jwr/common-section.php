
<?php


// HIDE THE USER LINK FROM THE MENU IF THE USER ROLE IS 'USER'

$user_fullname = $_SESSION['fullname'];
$user_email = $_SESSION['email'];
$user_role = $_SESSION['user_role'];
$profilePicture = $_SESSION['profile_picture'];

$manage_users = "";

if($user_role == 'admin'){
    $manage_users = '<li><a href="dash-user.php"><i class="fas fa-user"></i>จำนวนผู้ใช้</a></li>';
}

// Navbar Edit //
echo '<div class="sidebar">
        <div class="logo">
            <h2><a href="dashboard.php">JWR Warehouse Management System</a></h2> 
        </div>
        <ul>
            <li><a href="dashboard.php"><i class="fas fa-home"></i>หน้าหลัก</a></li>
            <li><a href="dash-prod.php"><i class="fas fa-box"></i>รายการสินค้า</a></li>
            <li><a href="dash-catg.php"><i class="fas fa-tags"></i>หมวดหมู่สินค้า</a></li>
            <li><a href="dash-cust.php"><i class="fas fa-users"></i>จำนวนลูกค้า</a></li>
            <li><a href="dash-order.php"><i class="fas fa-shopping-cart"></i>รายการสั่งชื้อ</a></li>
            <li><a href="report.php"><i class="fas fa-chart-line"></i> สรุปภาพรวม</a></li>
            '. $manage_users .'
        </ul>
    </div>
    <div class="main-content">
        <div class="header">
            <div class="user">
                <img src="'. $profilePicture .'" alt="User Image">
                <span>Welcome, '. $user_fullname .'</span>
            </div>
            <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i>ออกจากระบบ</a>
        </div>
        <div class="content">';
        

<?php
// เชื่อมต่อฐานข้อมูล
require 'db_connect.php';

// รับค่าจาก URL
$orderId = isset($_GET['orderId']) ? $_GET['orderId'] : '';
$orderDate = isset($_GET['orderDate']) ? $_GET['orderDate'] : '';
$customerName = isset($_GET['customerName']) ? $_GET['customerName'] : '';

// ดึงข้อมูลสินค้าพร้อมรูปภาพ
$query = "SELECT od.product_id, p.name AS product_name, od.quantity, p.price, (od.quantity * p.price) AS total_price, p.picture 
          FROM order_details od
          JOIN product p ON od.product_id = p.id
          WHERE od.order_id = :orderId";

$stmt = $conn->prepare($query);
$stmt->bindParam(':orderId', $orderId, PDO::PARAM_INT);
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// คำนวณราคารวม
$totalOrderValue = 0;
foreach ($rows as $row) {
    $totalOrderValue += $row['total_price'];
}
$vat = $totalOrderValue * 0.07;
$grandTotal = $totalOrderValue + $vat;
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ใบแจ้งหนี้</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f0f8ff;
            color: #333;
            padding: 20px;
        }
        .invoice-header {
            background-color: #0077b6;
            padding: 20px;
            text-align: center;
            color: white;
            font-size: 26px;
            font-weight: bold;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .customer-info, .total-amount {
            background-color: white;
            padding: 20px;
            margin: 20px 0;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .order-details {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .order-details thead {
            background-color: #0096c7;
            color: white;
        }
        .order-details th, .order-details td {
            padding: 12px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }
        .order-details tbody tr:nth-child(even) { background-color: #f0f8ff; }
        .order-details img {
            width: 60px; height: 60px;
            object-fit: cover;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        .total-amount { text-align: right; }
        .total-amount p {
            font-size: 20px;
            font-weight: bold;
            color:rgb(10, 10, 10);
        }
        /* ปุ่มกลับไปหน้าหลัก */
        .total-amount {
    position: relative; /* ใช้เป็นจุดอ้างอิงของปุ่ม */
    padding: 20px;
    background-color: white;
    margin: 20px 0;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    padding-bottom: 50px; /* กันพื้นที่ให้ปุ่ม */
}

.back-btn {
    position: absolute;
    bottom: 15px; /* ตรึงปุ่มให้อยู่ด้านล่าง */
    left: 15px; /* ตรึงปุ่มให้อยู่ด้านซ้าย */
    padding: 10px 18px;
    background-color: #d9534f;
    color: white;
    font-size: 15px;
    font-weight: bold;
    border-radius: 8px;
    text-decoration: none;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    display: flex;
    align-items: center;
    gap: 8px;
}

.back-btn i {
    font-size: 18px;
}

.back-btn:hover {
    background-color: #c9302c;
}

    </style>
</head>
<body>

    <div class="invoice-header">ใบแจ้งหนี้</div>

    <div class="customer-info">
        <p>รหัสใบสั่งซื้อ: <?= htmlspecialchars($orderId) ?></p>
        <p>วันที่สั่งซื้อ: <?= htmlspecialchars($orderDate) ?></p>
        <p>ชื่อลูกค้า: <?= htmlspecialchars($customerName) ?></p>
    </div>

    <table class="order-details">
        <thead>
            <tr>
                <th>รูปสินค้า</th>
                <th>รหัสสินค้า</th>
                <th>ชื่อสินค้า</th>
                <th>จำนวน</th>
                <th>ราคาต่อหน่วย</th>
                <th>รวมทั้งหมด</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (!empty($rows)) {
                foreach ($rows as $row) {
                    $imageUrl = !empty($row['picture']) ? htmlspecialchars($row['picture']) : 'images/default.png';
                    echo "<tr>";
                    echo "<td><img src='{$imageUrl}' alt='รูปสินค้า'></td>";
                    echo "<td>" . htmlspecialchars($row['product_id']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['product_name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['quantity']) . "</td>";
                    echo "<td>" . number_format($row['price'], 2) . "</td>";
                    echo "<td>" . number_format($row['total_price'], 2) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='6'>ไม่มีข้อมูลสินค้า</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <div class="total-amount">
        <p>ราคาสินค้าทั้งหมด: <?= number_format($totalOrderValue, 2) ?> บาท</p>
        <p>VAT 7%: <?= number_format($vat, 2) ?> บาท</p>
        <p>ราคาสุทธิ: <?= number_format($grandTotal, 2) ?> บาท</p>

    <div class="container">
    <!-- ปุ่มกลับไปหน้า home -->
    <a href="dashboard.php" class="back-btn"><i class="fas fa-arrow-left"></i> กลับไปหน้าแรก</a>
    </div>

    </div>
</body>
</html>